import {View,Text, TextInput, TouchableOpacity, Image, StyleSheet, Pressable} from 'react-native'
import {useState} from 'react'
import {Colors} from 'react-native/Libraries/NewAppScreen'
import Icon from 'react-native-vector-icons/MaterialIcons'
import 'react-native-gesture-handler'

const Home = (props) => {

  const GoDrawer = () => {
    props.navigation.navigate('Drawer')
  }

  const redirecionarAcoesPesquisa = () => {
    props.navigation.navigate('AcoesPesquisa')
  }
  
const redirecionarNovaPesquisa = () => {
  props.navigation.navigate('NovaPesquisa')
  }

return(
    <View style={estilos.view}>

      <View style={estilos.drawer}>
        <Pressable style={estilos.Botoes} onPress={GoDrawer}>
                  <Icon name='menu' size={40} color='white' />
        </Pressable>
      </View>

      <View>
        <Text style={estilos.txtHbusca}> <Icon name='search' size={25} color='gray'/> Insira o termo de busca </Text>
      </View>

      <View style={estilos.zHbotao}>

        <TouchableOpacity onPress={redirecionarAcoesPesquisa}> 
        <Text style={estilos.Hbotao}>
          <Icon name='devices' size={100} color='brown' /> {"\n"}SECOMP 2023{"\n"}
          <Text style={estilos.txtHbusca}>10/10/2023</Text>
        </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={redirecionarAcoesPesquisa}> 
        <Text style={estilos.Hbotao}>
          <Icon name='groups' size={100} color='grey' /> {"\n"}UBUNTU 2022{"\n"}
          <Text style={estilos.txtHbusca}>05/06/2022</Text>
        </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={redirecionarAcoesPesquisa}> 
        <Text style={estilos.Hbotao}>
          <Icon name='woman' size={100} color='red' /> {"\n"}MENINAS CPU{"\n"}
          <Text style={estilos.txtHbusca}>01/04/2022</Text>
        </Text>
        </TouchableOpacity>

      </View>

      <View>
        <TouchableOpacity style={estilos.mainButton} onPress={redirecionarNovaPesquisa}>
            <Text style={estilos.mainButtonText}>Nova Pesquisa</Text>
        </TouchableOpacity>
      </View>
    </View>
  )
}
const estilos = StyleSheet.create({
  view:{
    backgroundColor:'#372775',
    flex:1
  },
  drawer:{
    flex:0.4,
    backgroundColor:'#2B1D62',
  },
  txtHbusca:{
    fontSize: 18,
    backgroundColor:'white',
    color: '#8B8B8B',
    borderWidth: 1,
    marginHorizontal: 10,
    marginVertical:3,
  },
  zHbotao:{
    verticalAlign: 'middle',
    flexDirection: 'row',
    alignContent:'center',
    justifyContent: 'space-between',
    margin:10,
  },
  Hbotao:{
    backgroundColor:'white',
    alignContent:'center',
    textAlign:'center',
    color:'#3F92C5',
    fontSize:30,
    width:220,
    borderWidth:1,
    borderRadius:10,
  },
  txtzHbotao1:{
    color: '#3F92C5',
    textAlignVertical:'bottom'
  },
  txtzHbotao2:{
    color: '#3F92C5',
    textAlignVertical:'bottom'
  },
  txtHpesquisa:{
    borderWidth: 1,
    marginHorizontal:10,
    backgroundColor:'#37BD6D',
    fontSize:30,
    color: 'white',
    textAlign:'center',
    borderRadius:10,
  },
  mainButton: {
    backgroundColor: '#37BD6D',
    padding: 4,
    alignItems: 'center',
    marginTop: 5,
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: '#37BD6D',
    marginLeft: '2%',
    marginRight: '2%',
},
mainButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'AveriaLibre-Regular',
},
})

export default Home