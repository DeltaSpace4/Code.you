import { Text, View, StyleSheet, TouchableOpacity } from 'react-native'
import Icon from 'react-native-vector-icons/MaterialIcons'
import { useEffect } from 'react';

    const AgradecimentoParticipacao = ({ navigation }) => {
        useEffect(() => {
        const timer = setTimeout(() => {
            navigation.navigate('Home'); // Substituir para o menu quando implementado
        }, 3000);
        // Limpa o timer se o componente for desmontado antes dos 5 segundos
        return () => clearTimeout(timer);
        }, [navigation]);
        // Por algum motivo essa função foi a causa da corrupçao do grafico de pizza
    const redirecionarModificarPesquisa = () => {
        props.navigation.navigate('ModificarPesquisa')
    }

    return (
        <View style={estilos.container}>
            {/* Botão invisível para voltar */}
            <TouchableOpacity style={estilos.botaoVoltar} onPress={() => navigation.goBack()}>
                <Icon name="close" size={24} color="white" /> 
            </TouchableOpacity>
            
            {/* Ícone de fechar no canto superior direito 
            <TouchableOpacity onPress={() => navigation.goBack()}>
                <View style={estilos.rectangle}>
                    <Icon name="close" size={36} color="#FFFFFF" />
                </View>
            </TouchableOpacity>*/} 
            
            <Text style={estilos.headerText}>Obrigado por sua participação!</Text>
            <Text style={estilos.headerText}>Aguardamos você no próximo ano!</Text>
        </View>
    )
}

const estilos = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#372775',
        alignItems: 'center',
        justifyContent: 'center',
    },
    headerText: {
        width: '90%',
        textAlign: 'center',
        fontSize: 48,
        lineHeight: 57,
        fontFamily: 'Averia Libre',
        color: '#FFFFFF',
    },
    rectangle: {
        position: 'absolute',
        top: 10,
        right: 10,
        width: 43,
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#372775',
    },
    botaoVoltar: {
        position: 'absolute',
        top: 10,
        right: 10,  // Ajuste a posição do botão à esquerda do ícone de fechar
        width: 50,
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
    },
})

export default AgradecimentoParticipacao
