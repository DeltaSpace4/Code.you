import {View,Text, TextInput,TouchableOpacity, Image, StyleSheet,Pressable,Alert} from 'react-native'
import { useState } from 'react'
import { Colors } from 'react-native/Libraries/NewAppScreen'
import Icon from 'react-native-vector-icons/MaterialIcons'

const Coleta = ({ navigation }) => {

    const redirecionarAgradecimentoParticipacao = () => {
        navigation.navigate('AgradecimentoParticipacao')
    }


    return(
    <View style={estilos.view}>
        <Text style={estilos.Texto}>
            O que você acho do carnaval 2024?
        </Text>

        <View>

        <TouchableOpacity style={estilos.botaoVoltar} onPress={() => navigation.goBack()}>
                <Icon name="close" size={24} color="white" /> 
            </TouchableOpacity>

            <View style={estilos.Botoes} onPress={redirecionarAgradecimentoParticipacao}>

                <TouchableOpacity onPress={redirecionarAgradecimentoParticipacao}> 
                    <Icon name='mood-bad' size={100} color='red' />
                    <Text style={estilos.Texto2}>Pessimo</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={redirecionarAgradecimentoParticipacao}>
                    <Icon name='sentiment-dissatisfied' size={100} color='orange' />
                    <Text style={estilos.Texto2}>Ruim</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={redirecionarAgradecimentoParticipacao}>
                    <Icon name='sentiment-neutral' size={100} color='yellow' />
                    <Text style={estilos.Texto2}>Neutro</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={redirecionarAgradecimentoParticipacao}>
                    <Icon name='sentiment-satisfied' size={100} color='lime' />
                    <Text style={estilos.Texto2}>Bom</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={redirecionarAgradecimentoParticipacao}>
                    <Icon name='sentiment-very-satisfied' size={100} color='green' />
                    <Text style={estilos.Texto2}>Excelente</Text>
                </TouchableOpacity>
            </View>
        </View>
    </View>   
)
}

const estilos = StyleSheet.create({
    view:{
        backgroundColor:'#372775',
        flex:1
    },
    Texto:{
        flex:0.6,
        fontSize:40,
        color:'white',
        textAlignVertical:'center',
        textAlign:'center',
    },
    Botoes:{
        verticalAlign: 'middle',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems:'center',
        margin:2,
    },
    Texto2:{
        fontSize:25,
        flexDirection:'row',
        justifyContent:'space-between',
        color:'white',
        textAlignVertical:'top',
        textAlign:'center',
        margin:2,
    },
    botaoVoltar: {
        position: 'absolute',
        top: -100,
        right: 15,  // Ajuste a posição do botão à esquerda do ícone de fechar
        width: 50,
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
    },
})

export default Coleta