import { createDrawerNavigator, DrawerItem } from "@react-navigation/drawer";
import Home from "./Home";
import {View,Text, TextInput,TouchableOpacity, Image, StyleSheet,Pressable} from 'react-native'
import Icon from 'react-native-vector-icons/MaterialIcons'
import Login from "./Login";
import CustomDrawer from "../../CustomDrawer";

const DrawerNavigator = createDrawerNavigator()

const redirecionarAcoesPesquisa = () => {
    props.navigation.navigate('AcoesPesquisa')
  }

  const redirecionarLogin = () => {
    props.navigation.navigate('redirecionarLogin')
  }



const Drawer = (navigation) =>{

    const Sair = () => {
        props.navigation.navigate('Login')
    }

    return (
        <DrawerNavigator.Navigator  screenOptions={{headerRight:false,headerTintColor:'#372775',headerTransparent:true,headerTitle:'',drawerStyle:{backgroundColor:'#372775'},drawerLabel:()=>(<View style={{flexDirection:'row',backgroundColor:'#372775'}}><Text style={{fontSize:25,color:'white'}}>Usuario@domonio.com {"\n"}______________________{"\n"}<Icon name="description" size={30}  color={"white"} />Pesquisas{"\n"}{"\n"}{"\n"}{"\n"}{"\n"}{"\n"}<Icon name="logout" size={50}  color={"white"} />Sair</Text></View>),}}>

            <DrawerNavigator.Screen name="Home" component={Home} />

           
            
        
        </DrawerNavigator.Navigator>
    )
}
const estilos = StyleSheet.create({

botaoVoltar: {
    position: 'absolute',
    top: 10,
    right: 10,  // Ajuste a posição do botão à esquerda do ícone de fechar
    width: 50,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
},
})

export default Drawer