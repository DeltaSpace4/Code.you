import { Text, View, TextInput, TouchableOpacity, StyleSheet, setErrorMessage } from 'react-native'
import { useState } from 'react'
import Icon from 'react-native-vector-icons/MaterialIcons'

const NovaPesquisa = (props) => {
    const [txtNome, setNome] = useState('')
    const [txtData, setData] = useState('')

    const cadastrarPesquisa = () => {
        let nome = txtNome.trim()
        let data = txtData.trim()
    }

    const [mostrarMensagem, setMostrarMensagem] = useState(false)

    const redirecionarHome = () => {
        if (!txtNome.trim() || !txtData.trim()) {
            setMostrarMensagem(true)
        } else {
            props.navigation.navigate('Home');
        }
    }

    return (
        <View style={estilos.container}>
            <View style={estilos.form}>

                <Text style={estilos.label}>Nome</Text>
                <TextInput 
                    value={txtNome} 
                    onChangeText={setNome}
                    style={estilos.input}
                />

                <Text style={estilos.textoVermelho}>Preencha no nome da pesquisa</Text>

                <Text style={estilos.label}>Data</Text>
                <View style={estilos.inputComIcone}>
                    <TextInput 
                        value={txtData} 
                        onChangeText={setData}
                        placeholder="DD/MM/AAAA"
                        style={estilos.input}
                    />
                    <Icon name="calendar-month" size={30} color="#989898" style={{paddingLeft: 395,}}/>
                </View>

                <Text style={estilos.textoVermelho}>Preencha a data</Text>

                <Text style={mostrarMensagem ? estilos.textoVermelho : estilos.textoRoxo}>
                    Algum campo está vazio.
                </Text>

                <Text style={estilos.label}>Imagem</Text>
            </View>
                
            <View style={estilos.redirectButtons}>
                <TouchableOpacity style={estilos.mainButton} onPress={redirecionarHome}>
                    <Text style={estilos.mainButtonText}>CADASTRAR</Text>
                </TouchableOpacity>
            </View>
        </View>
    )    
}

const estilos = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#372775',
    },
    header: {
        width: '70%',
        flex: 0.2,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-evenly',
        minHeight: 80,
        maxHeight: 80,
    },
    title: {
        alignItems: 'center',
        fontSize: 40,
        color: '#FFFFFF',
        fontFamily: 'AveriaLibre-Regular',
    },
    form: {
        flex: 0.2,
        width: '70%',
        flexDirection: 'column',
        minHeight: 150,
        maxHeight: 150,
        marginBottom: 30,
    },
    label: {
        color: '#FFFFFF',
        fontSize: 16,
        marginTop: 10,
        fontFamily: 'AveriaLibre-Regular',
    },
    input: {
        padding: 7,
        fontSize: 16,
        backgroundColor: '#FFFFFF',
        color:'#3F92C5',
        fontFamily: 'AveriaLibre-Regular',
        height: '20%',
    },
    mainButton: {
        backgroundColor: '#37BD6D',
        padding: 4,
        alignItems: 'center',
        marginTop: 5,
        borderStyle: 'solid',
        borderWidth: 1,
        borderColor: '#37BD6D',
    },
    mainButtonText: {
        color: '#FFFFFF',
        fontSize: 16,
        fontFamily: 'AveriaLibre-Regular',
    },
    redirectButtons: {
        flex: 0.2,
        flexDirection: 'column',
        width: '70%',
        marginTop: 25,
        minHeight: 50,
        maxHeight: 50,
    },
    createAccountButton: {
        backgroundColor: '#419ED7',
        alignItems: 'center',
        borderStyle: 'solid',
        borderWidth: 1,
        borderColor: '#419ED7',
        marginBottom: 7,
    },
    createAccountText: {
        color: '#FFFFFF',
        paddingBottom: 1,
        fontFamily: 'AveriaLibre-Regular',
    },
    forgotPasswordButton: {
        backgroundColor: '#B0CCDE',
        alignItems: 'center',
        shadowColor: '#00000040',
        shadowOffset: {width: 0, height: 4},
        shadowOpacity: 0.25,
    },
    forgotPasswordText: {
        paddingBottom: 2,
        color: '#FFFFFF',
        fontFamily: 'AveriaLibre-Regular',
    },
    textoRoxo: {
        color: '#372775',
        fontFamily: 'AveriaLibre-Regular',
        paddingBottom: 8,
    },
    textoVermelho: {
        color: 'red',
        fontFamily: 'AveriaLibre-Regular',
        paddingBottom: 8,
    },
    inputComIcone: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#FFFFFF',
        paddingLeft: 10,
        height: 32,
    },
})

export default NovaPesquisa