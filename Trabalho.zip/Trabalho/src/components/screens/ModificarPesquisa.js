import { Text, View, TextInput, TouchableOpacity, StyleSheet, Image, Modal } from 'react-native'
import Icon from 'react-native-vector-icons/MaterialIcons'
import { useState } from 'react'

const ModificarPesquisa = ({ navigation }) => {
    const [txtNome, setNome] = useState('')
    const [txtData, setData] = useState('')

    const cadastrarPesquisa = () => {
        let nome = txtNome.trim()
        let data = txtData.trim()
    }

    const redirecionarHome = () => {
        navigation.navigate('Home')
    }

    const [isModalVisible, setIsModalVisible] = useState(false);

    return (
        <View style={estilos.container}>
            <View style={estilos.form}>

                <Text style={estilos.label}>Nome</Text>
                <TextInput 
                    value={txtNome} 
                    onChangeText={setNome}
                    style={estilos.input}
                />

                <Text style={estilos.label}>Data</Text>
                <View style={estilos.inputComIcone}>
                    <TextInput 
                        value={txtData} 
                        onChangeText={setData}
                        placeholder="DD/MM/AAAA"
                        style={estilos.input}
                    />
                    <Icon name="calendar-month" size={30} color="#989898" style={{paddingLeft: 395,}}/>
                </View>

                <Text style={estilos.label}>Imagem</Text>
                <View style={estilos.blocoImagem}>
                    <Icon name="celebration" size={60} color="#C60EB3"></Icon>
                </View>
           
            </View>
                
            <View style={estilos.redirectButtons}>
                <TouchableOpacity style={estilos.mainButton} onPress={redirecionarHome}>
                    <Text style={estilos.mainButtonText}>SALVAR</Text>
                </TouchableOpacity>

            <TouchableOpacity style={estilos.botaoEstatico} onPress={() => setIsModalVisible(true)}> 
                <Icon name="delete" size={40} color="#EEEEEE"/>
                <Text style={estilos.labelLixo}>Apagar</Text>
            </TouchableOpacity>

            <Modal
            visible={isModalVisible}
            onRequestClose={() => setIsModalVisible(false)}
            >
                <View style={{flex:1, backgroundColor: "#2B1F5C", padding: 60}}>
                    <Text style={estilos.label}>Tem certeza de apagar esta pesquisa?</Text>

                    <View style={estilos.containerModal}>
                        <TouchableOpacity style={[estilos.botaoModal, estilos.botaoSim]} onPress={redirecionarHome} >
                            <Text style={estilos.textoModal}>Sim</Text>
                        </TouchableOpacity>

                        <TouchableOpacity style={[estilos.botaoModal, estilos.botaoNao]} onPress={() => navigation.goBack()} >
                            <Text style={estilos.textoModal}>Não</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
            
            </View>
        </View>
    )    
}

const estilos = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        backgroundColor: '#372775',
    },
    header: {
        width: '70%',
        flex: 0.2,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-evenly',
        minHeight: 80,
        maxHeight: 80,
    },
    title: {
        alignItems: 'center',
        fontSize: 40,
        color: '#FFFFFF',
        fontFamily: 'AveriaLibre-Regular',
    },
    form: {
        flex: 0.2,
        width: '70%',
        flexDirection: 'column',
        minHeight: 150,
        maxHeight: 150,
        marginBottom: 30,
    },
    label: {
        color: '#FFFFFF',
        fontSize: 16,
        marginTop: 10,
        fontFamily: 'AveriaLibre-Regular',
    },
    input: {
        padding: 7,
        fontSize: 16,
        backgroundColor: '#FFFFFF',
        color:'#3F92C5',
        fontFamily: 'AveriaLibre-Regular',
        height: '20%',
    },
    mainButton: {
        backgroundColor: '#37BD6D',
        padding: 4,
        alignItems: 'center',
        height: 30,
        marginTop: 25,
        borderStyle: 'solid',
        borderWidth: 1,
        borderColor: '#37BD6D',
    },
    mainButtonText: {
        color: '#FFFFFF',
        fontSize: 16,
        fontFamily: 'AveriaLibre-Regular',
    },
    redirectButtons: {
        flex: 0.2,
        flexDirection: 'column',
        width: '70%',
        marginTop: 25,
        minHeight: 50,
        maxHeight: 50,
    },
    backgroundIconeAcoesPesquisa: {
        alignItems: 'center',
        backgroundColor: "#312464",
    },
    blocoImagem: {
        backgroundColor: '#FFFFFF', 
        justifyContent: 'center', 
        alignItems: 'center', 
        width: '50%',
        height: 60, 
        borderRadius: 5, 
    },
    inputComIcone: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#FFFFFF',
        paddingLeft: 10,
        height: 32,
    },
    botaoEstatico: {
        position: 'absolute',
        top: 20,
        right: -80,  
        alignItems: 'center',
        justifyContent: 'center',
    },
    labelLixo: {
        color: '#FFFFFF',
        fontSize: 16,
        fontFamily: 'AveriaLibre-Regular',
    },
    botaoSim: {
        backgroundColor: '#F57C7C', // Vermelho rosado
    },
    botaoNao: {
        backgroundColor: '#87CEFA', // Azul claro
    },
    containerModal: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '100%',
        marginTop: 10,
    },
    textoModal: {
        color: '#FFFFFF',
        fontSize: 16,
        fontWeight: 'bold',
    },
    botaoModal: {
        flex: 1,
        marginHorizontal: 5,
        paddingVertical: 10,
        borderRadius: 5,
        alignItems: 'center',
    },
})

export default ModificarPesquisa